# -*- coding: utf-8 -*-
import json, re

RAMPA = ['#A8E02A','#6DCC48','#3DBF6E','#2EC28A','#1ABC9C']
FONDO='#DBE2E7'; CARD='#E9EEF1'; BORDE='#CBD5DC'; CAMPO='#DDE5E9'
TINTA='#0F1518'; SEC='#4A555C'; TENUE='#5F6B73'   # tenue subido a 4.8:1 sobre el campo
TEAL='#086A5E'
FAM = "Poppins,'Segoe UI',Arial,sans-serif"
EXACT = "mso-line-height-rule:exactly;"

def barra():
    c=''.join('<td width="20%%" height="6" bgcolor="%s" style="background-color:%s;font-size:0;line-height:6px;%s">&nbsp;</td>'
              %(x,x,EXACT) for x in RAMPA)
    return ('<table role="presentation" width="100%%" cellpadding="0" cellspacing="0" border="0" '
            'style="border-collapse:collapse;"><tr>%s</tr></table>')%c

def boton(texto,href):
    ancho = max(190, len(texto)*11 + 62)
    return f"""<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:28px 0 8px;border-collapse:separate;">
<tr><td align="center" bgcolor="{TEAL}" style="background-color:{TEAL};border-radius:10px;padding:15px 30px;{EXACT}line-height:20px;">
<!--[if mso]><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="{href}" style="height:50px;v-text-anchor:middle;width:{ancho}px;" arcsize="20%" stroke="f" fillcolor="{TEAL}"><w:anchorlock/><center style="color:#FFFFFF;font-family:Arial,sans-serif;font-size:16px;font-weight:bold;">{texto}</center></v:roundrect><![endif]-->
<!--[if !mso]><!-- --><a href="{href}" style="font-family:{FAM};font-size:16px;font-weight:600;color:#FFFFFF;text-decoration:none;line-height:20px;">{texto}</a><!--<![endif]-->
</td></tr></table>"""

def p(txt,color=None,size=16,mt=0,mb=16,lh=None):
    color = color or TINTA
    lh = lh or int(size*1.65)
    return (f'<p style="margin:{mt}px 0 {mb}px;font-family:{FAM};font-size:{size}px;'
            f'line-height:{lh}px;{EXACT}font-weight:400;color:{color};">{txt}</p>')

def dato(etiqueta,valor,mono=False):
    fam = "'SFMono-Regular',Consolas,'Courier New',monospace" if mono else FAM
    tam = 22 if mono else 17
    return (f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'style="margin:0 0 14px;border-collapse:separate;"><tr>'
            f'<td bgcolor="{CAMPO}" style="background-color:{CAMPO};border:1px solid {BORDE};'
            f'border-radius:10px;padding:16px 18px;">'
            f'<div style="font-family:{FAM};font-size:11px;line-height:14px;{EXACT}letter-spacing:.09em;'
            f'text-transform:uppercase;color:{TENUE};padding-bottom:6px;">{etiqueta}</div>'
            f'<div style="font-family:{fam};font-size:{tam}px;line-height:{tam+6}px;{EXACT}'
            f'font-weight:bold;color:{TINTA};letter-spacing:.04em;">{valor}</div>'
            f'</td></tr></table>')

RELLENO = '&#847;&zwnj;&nbsp;' * 60

def envoltura(preheader, cuerpo):
    return f"""<!doctype html>
<html lang="es-MX" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="x-apple-disable-message-reformatting">
<meta name="color-scheme" content="light only">
<meta name="supported-color-schemes" content="light only">
<title>ATP</title>
<!--[if mso]><noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>
<style>body,table,td,p,a,div{{font-family:Arial,sans-serif !important}}</style><![endif]-->
<style>
  :root{{color-scheme:light only;supported-color-schemes:light only}}
  a{{color:{TEAL}}}
  @media (max-width:620px){{
    .caja{{padding:28px 22px !important}}
    .h1{{font-size:25px !important;line-height:31px !important}}
  }}
</style>
</head>
<body style="margin:0;padding:0;background-color:{FONDO};" bgcolor="{FONDO}">
<div style="display:none;font-size:1px;color:{FONDO};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">{preheader}{RELLENO}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="{FONDO}" style="background-color:{FONDO};border-collapse:collapse;">
<tr><td align="center" style="padding:32px 16px 48px;">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;border-collapse:collapse;">

<tr><td align="center" style="padding:0 0 26px;">
<img src="https://somosatp.com/correo/logo-atp.png" width="148" alt="ATP" style="display:block;border:0;outline:none;text-decoration:none;width:148px;height:auto;">
</td></tr>

<tr><td bgcolor="{CARD}" style="background-color:{CARD};border:1px solid {BORDE};border-radius:16px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
<tr><td style="border-radius:16px 16px 0 0;overflow:hidden;">{barra()}</td></tr>
<tr><td class="caja" style="padding:38px 38px 34px;">
{cuerpo}
</td></tr></table>
</td></tr>

<tr><td style="padding:26px 8px 0;">
<p style="margin:0 0 8px;font-family:{FAM};font-size:13px;line-height:20px;{EXACT}color:{SEC};">
Te escribimos porque compraste una membresía ATP. Si no fuiste tú, respóndenos y lo revisamos.
</p>
<p style="margin:0;font-family:{FAM};font-size:13px;line-height:20px;{EXACT}color:{SEC};">
ATP · Querétaro, México · <a href="https://somosatp.com" style="color:{TEAL};text-decoration:none;">somosatp.com</a>
</p>
</td></tr>

</table></td></tr></table></body></html>"""

H  = lambda t: (f'<h1 class="h1" style="margin:0 0 20px;font-family:{FAM};font-size:29px;'
                f'line-height:35px;{EXACT}font-weight:bold;color:{TINTA};letter-spacing:-.012em;">{t}</h1>')
H2 = lambda t: (f'<h2 style="margin:0 0 14px;font-family:{FAM};font-size:17px;line-height:23px;{EXACT}'
                f'font-weight:bold;color:{TINTA};">{t}</h2>')
HR = (f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">'
      f'<tr><td height="1" bgcolor="{BORDE}" style="background-color:{BORDE};font-size:0;line-height:1px;{EXACT}">&nbsp;</td></tr>'
      f'</table><div style="height:26px;line-height:26px;font-size:0;{EXACT}">&nbsp;</div>')
ESP = lambda h=26: f'<div style="height:{h}px;line-height:{h}px;font-size:0;{EXACT}">&nbsp;</div>'
B  = lambda t: f'<strong style="color:{TINTA};font-weight:bold;">{t}</strong>'
WA = 'https://wa.me/{{whatsapp_e164}}'

# ═══════════════ 1 · ACCESO LISTO ═══════════════
c1 = (
 H('Tu acceso ya quedó, {{nombre}}')
 + p('Recibimos tu pago y tu cuenta está activa desde este momento. Abajo está todo lo que necesitas para entrar.')
 + dato('Tu código de activación','{{codigo}}',mono=True)
 + dato('Tu membresía corre hasta','{{vence}}')
 + boton('Abrir mi acceso','{{url_acceso}}')
 + p('Esa página guarda tu código, los enlaces de descarga para iPhone y para Android, y la entrada a la comunidad. Guárdala, porque es la misma siempre.', color=SEC, size=15, mt=4)
 + ESP(4) + HR
 + H2('Cómo entras, en tres pasos')
 + p(f'Descargas la app desde el enlace que está en tu página de acceso. Creas tu cuenta con este mismo correo, {B("{{email}}")}, porque así el sistema te reconoce solo. Y si por lo que sea no te reconoce, entras a Ajustes, tocas Suscripción, tocas Tengo un código y pegas el que está arriba.', color=SEC, size=15)
 + p('El primer día la app te va a preguntar bastante. Contesta con calma, porque de ahí sale todo lo demás.', color=SEC, size=15, mb=0)
 + ESP() + HR
 + p(f'Si algo no te abre, responde a este correo o escríbenos al WhatsApp <a href="{WA}" style="color:{TEAL};text-decoration:none;font-weight:bold;">{{{{whatsapp_visible}}}}</a>. Del otro lado hay alguien.', color=SEC, size=15, mb=0)
)
t1 = """Tu acceso ya quedó, {{nombre}}

Recibimos tu pago y tu cuenta está activa desde este momento.

Tu código de activación: {{codigo}}
Tu membresía corre hasta: {{vence}}

Abre tu página de acceso: {{url_acceso}}
Ahí están ese mismo código, los enlaces de descarga para iPhone y para Android, y la entrada a la comunidad. Guárdala, porque es la misma siempre.

CÓMO ENTRAS, EN TRES PASOS
Descargas la app desde el enlace que está en tu página de acceso. Creas tu cuenta con este mismo correo, {{email}}, porque así el sistema te reconoce solo. Y si por lo que sea no te reconoce, entras a Ajustes, tocas Suscripción, tocas Tengo un código y pegas el que está arriba.

El primer día la app te va a preguntar bastante. Contesta con calma, porque de ahí sale todo lo demás.

Si algo no te abre, responde a este correo o escríbenos al WhatsApp {{whatsapp_visible}}. Del otro lado hay alguien.

ATP · Querétaro, México · somosatp.com
Te escribimos porque compraste una membresía ATP."""

# ═══════════════ 2 · COMPROBANTE ═══════════════
c2 = (
 H('Recibimos tu comprobante')
 + p('Hola {{nombre}}, ya nos llegó y está en revisión. La verificación tarda un día hábil como máximo.')
 + dato('Referencia de tu pago','{{referencia}}',mono=True)
 + dato('Lo recibimos el','{{fecha_recepcion}}')
 + p('En cuanto quede confirmada te llega un correo con tu código de activación y tu enlace de entrada. No tienes que hacer nada mientras tanto.', color=SEC, size=15)
 + ESP(8) + HR
 + p('Si el comprobante salió cortado o le falta la referencia, responde a este correo con la imagen completa. Se corrige sin que empieces de nuevo.', color=SEC, size=15, mb=0)
)
t2 = """Recibimos tu comprobante

Hola {{nombre}}, ya nos llegó y está en revisión. La verificación tarda un día hábil como máximo.

Referencia de tu pago: {{referencia}}
Lo recibimos el: {{fecha_recepcion}}

En cuanto quede confirmada te llega un correo con tu código de activación y tu enlace de entrada. No tienes que hacer nada mientras tanto.

Si el comprobante salió cortado o le falta la referencia, responde a este correo con la imagen completa. Se corrige sin que empieces de nuevo.

ATP · Querétaro, México · somosatp.com"""

# ═══════════════ 3 · ACTIVACIÓN PENDIENTE ═══════════════
c3 = (
 H('Tu pago sigue sin canjearse')
 + p('Tu membresía quedó pagada el {{fecha_pago}} y ya está corriendo, {{nombre}}, pero tu cuenta todavía no se abre con el código que te mandamos.')
 + p('Lo más común es que el primer correo se haya ido a spam. Aquí va otra vez, con la liga directa.', color=SEC, size=15)
 + dato('Tu código de activación','{{codigo}}',mono=True)
 + boton('Abrir mi acceso','{{url_acceso}}')
 + ESP(14) + HR
 + p('Si ya lo intentaste y no jaló, responde a este correo. Lo resolvemos hoy.', color=SEC, size=15, mb=0)
)
t3 = """Tu pago sigue sin canjearse

Tu membresía quedó pagada el {{fecha_pago}} y ya está corriendo, {{nombre}}, pero tu cuenta todavía no se abre con el código que te mandamos.

Lo más común es que el primer correo se haya ido a spam. Aquí va otra vez, con la liga directa.

Tu código de activación: {{codigo}}
Abre tu página de acceso: {{url_acceso}}

Si ya lo intentaste y no jaló, responde a este correo. Lo resolvemos hoy.

ATP · Querétaro, México · somosatp.com"""

# ═══════════════ 4 · CONTRASEÑA (plantilla Go de Supabase) ═══════════════
c4 = (
 H('Restablece tu contraseña')
 + p('Alguien pidió cambiar la contraseña de la cuenta {{ .Email }}. Si fuiste tú, el botón de abajo te lleva a ponerla.')
 + boton('Poner nueva contraseña','{{ .SiteURL }}/reset-password?token_hash={{ .TokenHash }}&amp;type=recovery')
 + p('El enlace sirve una sola vez y dura poco, a propósito. Si ya venció, pides otro desde la pantalla de entrada de la app.', color=SEC, size=15, mt=8)
 + ESP(10) + HR
 + p('Si no fuiste tú, ignora este correo. Tu contraseña sigue igual y nadie entró a tu cuenta. Si te llegan varios de estos seguidos, avísanos.', color=SEC, size=15, mb=0)
)
t4 = """Restablece tu contraseña

Alguien pidió cambiar la contraseña de la cuenta {{ .Email }}. Si fuiste tú, abre este enlace para ponerla:

{{ .SiteURL }}/reset-password?token_hash={{ .TokenHash }}&type=recovery

El enlace sirve una sola vez y dura poco, a propósito. Si ya venció, pides otro desde la pantalla de entrada de la app.

Si no fuiste tú, ignora este correo. Tu contraseña sigue igual y nadie entró a tu cuenta.

ATP · Querétaro, México · somosatp.com"""

# ═══════════════ 5 · COBRO FALLIDO ═══════════════
c5 = (
 H('No pudimos cobrar tu renovación')
 + p('Hola {{nombre}}, el banco rechazó el cargo de tu membresía. Suele ser una tarjeta vencida, un límite del mes, o que el banco lo marcó por precaución.')
 + p('Tu acceso sigue abierto hasta el {{gracia}}. Lo vamos a reintentar solo, pero si actualizas la tarjeta se resuelve al momento.', color=SEC, size=15)
 + boton('Actualizar mi tarjeta','{{url_portal}}')
 + ESP(14) + HR
 + p('Si prefieres pagar por transferencia, responde a este correo y te pasamos los datos. Tus registros y tu historial no se tocan mientras esto se arregla.', color=SEC, size=15, mb=0)
)
t5 = """No pudimos cobrar tu renovación

Hola {{nombre}}, el banco rechazó el cargo de tu membresía. Suele ser una tarjeta vencida, un límite del mes, o que el banco lo marcó por precaución.

Tu acceso sigue abierto hasta el {{gracia}}. Lo vamos a reintentar solo, pero si actualizas la tarjeta se resuelve al momento.

Actualiza tu tarjeta: {{url_portal}}

Si prefieres pagar por transferencia, responde a este correo y te pasamos los datos. Tus registros y tu historial no se tocan mientras esto se arregla.

ATP · Querétaro, México · somosatp.com"""

CORREOS = [
 ('01-acceso-listo',        'Tu acceso a ATP ya quedó',          'Tu código de activación y tu enlace de entrada están aquí.', c1, t1),
 ('02-comprobante-recibido','Recibimos tu comprobante',          'Está en revisión. Un día hábil como máximo.',                c2, t2),
 ('03-activacion-pendiente','Tu pago de ATP sigue sin canjearse','Tu código sigue esperando. Aquí va otra vez.',               c3, t3),
 ('04-contrasena',          'Restablece tu contraseña de ATP',   'Un enlace de un solo uso para poner tu contraseña.',         c4, t4),
 ('05-cobro-fallido',       'No pudimos cobrar tu renovación',   'El banco rechazó el cargo. Tu acceso sigue abierto.',        c5, t5),
]
asuntos = {}
for slug, asunto, pre, cuerpo, texto in CORREOS:
    open(slug+'.html','w',encoding='utf-8').write(envoltura(pre,cuerpo))
    open(slug+'.txt','w',encoding='utf-8').write(texto)
    asuntos[slug] = {'asunto':asunto,'preheader':pre}
    n=len(open(slug+'.html',encoding='utf-8').read().encode())
    print(f'{slug:26} {n:>7} bytes  {"OK" if n<102000 else "PASA DE 102KB"}')
open('asuntos.json','w',encoding='utf-8').write(json.dumps(asuntos,ensure_ascii=False,indent=2))
