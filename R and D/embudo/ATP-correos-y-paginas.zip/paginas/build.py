# -*- coding: utf-8 -*-
from base import pagina

SOPORTE_WA = "{{WHATSAPP_E164}}"      # 5214421234567
SOPORTE_WA_VIS = "{{WHATSAPP_VISIBLE}}"  # 442 123 4567
CORREO = "hola@somosatp.com"

PIE = f"""<p class="pie">
Si algo no te abre, responde el correo que te llegó o escríbenos por
<a href="https://wa.me/{SOPORTE_WA}">WhatsApp al {SOPORTE_WA_VIS}</a>,
o a <a href="mailto:{CORREO}">{CORREO}</a>. Contestamos nosotros.
</p>"""

# ══════════════════════ 1 · GRACIAS ══════════════════════
gracias = pagina("Gracias · ATP", f"""
<h1>Listo, ya quedó tu pago</h1>
<p class="lead">Tu membresía está activa desde este momento. Ahora te va a llegar tu código de activación y tu enlace de entrada, y con eso ya estás dentro.</p>

<div class="tarjeta">
  <h2>Qué pasa en el próximo minuto</h2>
  <div class="paso"><div class="num">1</div><div><p><strong>Te llega un correo</strong> con tu código de activación y la liga a tu página de acceso. Revisa la bandeja de promociones y la de spam, porque los correos con códigos se van para allá con frecuencia.</p></div></div>
  <div class="paso"><div class="num">2</div><div><p><strong>Te llega un WhatsApp</strong> con lo mismo, por si el correo se pierde. Ese chat es también por donde nos escribes si algo no abre.</p></div></div>
  <div class="paso"><div class="num">3</div><div><p><strong>Descargas la app</strong> y creas tu cuenta con el mismo correo con el que pagaste. El sistema te reconoce solo, y si no, pegas el código.</p></div></div>
</div>

<div class="aviso"><p><strong>Si en cinco minutos no te llegó nada</strong>, escríbenos ahí mismo por WhatsApp con el correo que usaste para pagar y te damos el acceso en el momento. Ningún pago se queda sin acceso.</p></div>

<div class="fila">
  <a class="btn" href="https://wa.me/{SOPORTE_WA}?text=Ya%20pagu%C3%A9%20y%20no%20me%20lleg%C3%B3%20mi%20acceso">Escribirnos por WhatsApp</a>
  <a class="btn fantasma" href="https://somosatp.com">Volver al sitio</a>
</div>

<div class="hr"></div>
<h2>Mientras te llega</h2>
<p>Vale la pena entrar con el teléfono cargado y veinte minutos libres. El primer día la app pregunta bastante, y de esas respuestas sale todo lo que hace después. Contestar de prisa la primera vez se paga caro después.</p>
{PIE}
""")

# ══════════════════════ 2 · MI ACCESO ══════════════════════
JS_ACCESO = """
<script>
(function(){
  // El token viaja en la ruta (/mi-acceso/ABC123, via .htaccess) o en ?t=ABC123.
  var m = location.pathname.match(/\\/mi-acceso\\/([A-Za-z0-9_-]+)/);
  var token = (m && m[1]) || new URLSearchParams(location.search).get('t');

  var $ = function(id){ return document.getElementById(id); };
  function mostrar(estado){
    ['cargando','datos','error'].forEach(function(e){ $(e).classList.toggle('oculto', e !== estado); });
  }
  function limpiarURL(){ try { history.replaceState(null,'','/mi-acceso'); } catch(e){} }

  if (!token) { mostrar('error'); return; }

  var ctl = new AbortController();
  var reloj = setTimeout(function(){ ctl.abort(); }, 12000);

  fetch(ATP_ENDPOINT + '?t=' + encodeURIComponent(token), { signal: ctl.signal })
    .then(function(r){ if(!r.ok) throw new Error(r.status); return r.json(); })
    .then(function(d){
      clearTimeout(reloj);
      $('saludo').textContent = d.nombre ? ('Aqu\u00ed est\u00e1 tu acceso, ' + d.nombre) : 'Aqu\u00ed est\u00e1 tu acceso';
      $('codigo').textContent = d.codigo;
      $('vence').textContent  = d.vence;
      $('plan').textContent   = d.plan;
      if (d.ya_activada) $('activada').classList.remove('oculto');
      mostrar('datos');
      limpiarURL();   // el token no se queda en el historial
    })
    .catch(function(){ clearTimeout(reloj); mostrar('error'); limpiarURL(); });

  $('copiar').addEventListener('click', function(){
    var b = $('copiar'), t = $('codigo').textContent.trim();
    function ok(){ var o = b.textContent; b.textContent = 'Copiado'; setTimeout(function(){ b.textContent = o; }, 1800); }
    function falla(){ b.textContent = 'Selecciona y copia el c\u00f3digo de arriba'; }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(t).then(ok).catch(falla);
    } else { falla(); }
  });
})();
</script>"""

acceso = pagina("Mi acceso · ATP", f"""
<div id="cargando"><p class="lead">Cargando tu acceso...</p></div>

<div id="error" class="oculto">
  <h1>Este enlace ya no sirve</h1>
  <p class="lead">Se pudo cortar al copiarlo del correo, o ya venció.</p>
  <p>Escríbenos por WhatsApp con el correo que usaste para pagar y te mandamos uno nuevo en el momento. No pierdes nada de tu membresía por esto.</p>
  <div class="fila"><a class="btn" href="https://wa.me/{SOPORTE_WA}?text=Mi%20enlace%20de%20acceso%20no%20funciona">Pedir un enlace nuevo</a></div>
</div>

<div id="datos" class="oculto">
  <h1 id="saludo">Aquí está tu acceso</h1>
  <p class="lead">Esta página es la misma siempre. Guárdala en favoritos y no vuelves a buscar nada.</p>

  <div class="tarjeta">
    <div class="campo">
      <div class="etiqueta">Tu código de activación</div>
      <div class="codigo" id="codigo">ATP-0000-0000</div>
    </div>
    <div class="fila"><button class="btn" id="copiar">Copiar código</button></div>
    <div id="activada" class="aviso oculto" style="margin-top:22px"><p>Tu cuenta ya está activa con este código. Lo dejamos aquí solo como respaldo.</p></div>
  </div>

  <div class="tarjeta">
    <div class="campo"><div class="etiqueta">Tu plan</div><div class="valor" id="plan">ATP</div></div>
    <div class="campo" style="margin-bottom:0"><div class="etiqueta">Corre hasta</div><div class="valor" id="vence">-</div></div>
  </div>

  <div class="hr"></div>

  <h2>1 · Descarga la app</h2>
  <p>Bájala en el teléfono donde la vas a usar todos los días. Es donde va a vivir el sistema.</p>
  <div class="fila">
    <a class="btn fantasma" href="{{{{URL_APP_STORE}}}}">iPhone</a>
    <a class="btn fantasma" href="{{{{URL_PLAY_STORE}}}}">Android</a>
  </div>

  <div class="hr"></div>

  <h2>2 · Crea tu cuenta y activa</h2>
  <p>Usa el mismo correo con el que pagaste y el sistema te reconoce solo. Si no te reconoce, entras a Ajustes, tocas Suscripción, tocas Tengo un código y pegas el de arriba.</p>

  <div class="hr"></div>

  <h2>3 · Entra a la comunidad</h2>
  <p>Ahí están las sesiones en vivo, las preguntas que ya contestamos y la gente que va en tu misma etapa. La app es el sistema, la comunidad es la gente. Las dos hacen falta.</p>
  <div class="fila"><a class="btn fantasma" href="{{{{URL_SKOOL}}}}">Abrir la comunidad</a></div>
  <p style="font-size:15px">Entra con este mismo correo. Si te pide aceptar una invitación y no la ves, búscala en spam o escríbenos y te la reenviamos.</p>

  {PIE}
</div>
""", extra_js='<script>var ATP_ENDPOINT="{{URL_FUNCION_ACCESO}}";</script>' + JS_ACCESO)

# ══════════════════════ 3 · CONTRASEÑA ══════════════════════
JS_PASS = """
<script>
(function(){
  var $ = function(id){ return document.getElementById(id); };
  function ver(cual){
    ['cargandoPass','formulario','listo','sinToken','sinVerifier'].forEach(function(id){
      $(id).classList.toggle('oculto', id !== cual);
    });
  }
  function decir(t, malo){ var m = $('msg'); m.textContent = t; m.style.color = malo ? '#E74C3C' : '#999999'; }
  function limpiarURL(){ try { history.replaceState(null,'',location.pathname); } catch(e){} }

  var API = ATP_SUPABASE_URL.replace(/\\/+$/,'') + '/auth/v1';
  var CAB = { 'Content-Type':'application/json', 'apikey': ATP_SUPABASE_ANON };
  var sesion = null;

  function post(ruta, cuerpo){
    return fetch(API + ruta, { method:'POST', headers:CAB, body:JSON.stringify(cuerpo) })
      .then(function(r){ return r.json().then(function(j){ return { ok:r.ok, j:j }; }); });
  }

  // Supabase manda el enlace de tres formas distintas segun como se pidio el cambio.
  // Hay que aceptar las tres, porque la app y la web no siempre usan el mismo flujo.
  function abrirSesion(){
    var q = new URLSearchParams(location.search);
    var h = new URLSearchParams(location.hash.replace(/^#/,''));

    // a) token_hash. Es el que arma la plantilla de correo de ATP, y el que
    //    aguanta que un escaner de correo abra la liga antes que la persona.
    var th = q.get('token_hash');
    if (th) {
      return post('/verify', { type:'recovery', token_hash: th })
        .then(function(r){ if (r.ok && r.j.access_token) { sesion = r.j.access_token; return 'ok'; } return 'vencido'; });
    }

    // b) fragmento, flujo implicito
    if (h.get('access_token') && h.get('type') === 'recovery') {
      sesion = h.get('access_token');
      return Promise.resolve('ok');
    }

    // c) PKCE. El verificador vive en el mismo aparato que pidio el cambio.
    //    Si lo pidieron desde la app, aqui en el navegador no existe.
    var code = q.get('code');
    if (code) {
      var v = null;
      try {
        for (var i = 0; i < localStorage.length; i++) {
          var k = localStorage.key(i);
          if (k && k.indexOf('code-verifier') !== -1) { v = JSON.parse(localStorage.getItem(k)); break; }
        }
      } catch(e){}
      if (typeof v === 'string' && v) {
        return post('/token?grant_type=pkce', { auth_code: code, code_verifier: v })
          .then(function(r){ if (r.ok && r.j.access_token) { sesion = r.j.access_token; return 'ok'; } return 'vencido'; });
      }
      return Promise.resolve('sinVerifier');
    }
    return Promise.resolve('vencido');
  }

  var reloj = setTimeout(function(){ ver('sinToken'); }, 15000);

  abrirSesion().then(function(estado){
    clearTimeout(reloj); limpiarURL();
    if (estado === 'ok') ver('formulario');
    else if (estado === 'sinVerifier') ver('sinVerifier');
    else ver('sinToken');
  }).catch(function(){ clearTimeout(reloj); limpiarURL(); ver('sinToken'); });

  $('form').addEventListener('submit', function(e){
    e.preventDefault();
    var a = $('pass').value, b = $('pass2').value;
    if (a.length < 8) return decir('La contrase\\u00f1a necesita al menos ocho caracteres.', true);
    if (a !== b)      return decir('Las dos contrase\\u00f1as no coinciden.', true);
    $('enviar').disabled = true; decir('Guardando...');

    fetch(API + '/user', {
      method:'PUT',
      headers:{ 'Content-Type':'application/json', 'apikey': ATP_SUPABASE_ANON, 'Authorization':'Bearer ' + sesion },
      body: JSON.stringify({ password: a })
    })
    .then(function(r){ return r.json().then(function(j){ return { ok:r.ok, j:j }; }); })
    .then(function(r){
      if (r.ok) { ver('listo'); return; }
      $('enviar').disabled = false;
      decir(r.j.msg || r.j.error_description || r.j.message || 'No se pudo guardar. Pide otro enlace desde la app.', true);
    })
    .catch(function(){ $('enviar').disabled = false; decir('No hubo conexi\\u00f3n. Int\\u00e9ntalo otra vez.', true); });
  });
})();
</script>"""

contrasena = pagina("Nueva contraseña · ATP", """
<div id="cargandoPass"><p class="lead">Revisando tu enlace...</p></div>

<div id="formulario" class="oculto">
  <h1>Pon tu contraseña nueva</h1>
  <p class="lead">Ocho caracteres mínimo, y que no la uses en otro lado.</p>
  <form id="form" class="tarjeta">
    <div class="campo" style="padding:14px 16px">
      <label class="etiqueta" for="pass">Contraseña nueva</label>
      <input id="pass" type="password" autocomplete="new-password" required minlength="8"
        style="width:100%;background:transparent;border:0;outline:0;color:#fff;font-family:inherit;font-size:18px;padding:2px 0">
    </div>
    <div class="campo" style="padding:14px 16px">
      <label class="etiqueta" for="pass2">Otra vez, para confirmar</label>
      <input id="pass2" type="password" autocomplete="new-password" required minlength="8"
        style="width:100%;background:transparent;border:0;outline:0;color:#fff;font-family:inherit;font-size:18px;padding:2px 0">
    </div>
    <div class="fila" style="margin-top:6px"><button class="btn" id="enviar" type="submit">Guardar contraseña</button></div>
    <p id="msg" style="margin:14px 0 0;font-size:15px;min-height:22px;color:#999999"></p>
  </form>
</div>

<div id="listo" class="oculto">
  <h1>Ya quedó</h1>
  <p class="lead">Tu contraseña está cambiada. Vuelve a la app y entra con ella.</p>
  <p>Si te cerró la sesión en otros dispositivos, es a propósito. Vuelve a entrar en cada uno con la contraseña nueva.</p>
</div>

<div id="sinToken" class="oculto">
  <h1>Este enlace ya venció</h1>
  <p class="lead">Los enlaces para cambiar contraseña sirven una sola vez y duran poco, a propósito.</p>
  <p>Pide otro desde la pantalla de entrada de la app, en Olvidé mi contraseña. Te llega en menos de un minuto.</p>
</div>

<div id="sinVerifier" class="oculto">
  <h1>Abre este enlace desde tu teléfono</h1>
  <p class="lead">Pediste el cambio desde la app, así que el enlace solo se puede terminar en ese mismo aparato.</p>
  <p>Abre el correo en el teléfono donde tienes ATP y toca el botón desde ahí. Si ya no tienes ese correo a la mano, pide otro enlace desde la pantalla de entrada de la app.</p>
</div>
""", extra_js='<script>var ATP_SUPABASE_URL="{{SUPABASE_URL}}";var ATP_SUPABASE_ANON="{{SUPABASE_ANON_KEY}}";</script>' + JS_PASS)

for nombre, html in [('gracias.html',gracias),('mi-acceso.html',acceso),('reset-password.html',contrasena)]:
    open(nombre,'w',encoding='utf-8').write(html)
    print('escrito:',nombre,len(html),'bytes')
