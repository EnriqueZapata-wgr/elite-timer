# -*- coding: utf-8 -*-
"""Plantillas de correo de Supabase Auth · ATP · español, con marca."""
import json, os
from shell import envoltura, boton, p, dato, H, H2, HR, ESP, B, SEC, TINTA, TEAL

SITIO = '{{ .SiteURL }}'
CONF  = SITIO + '/confirmar.html?token_hash={{ .TokenHash }}&amp;type='
RESET = SITIO + '/reset-password.html?token_hash={{ .TokenHash }}&amp;type='
AVISO = ('Si no fuiste tú, escríbenos respondiendo a este correo. '
         'Nadie más puede entrar a tu cuenta con este mensaje.')

os.makedirs('autenticacion', exist_ok=True)
os.makedirs('seguridad', exist_ok=True)
IDX = []

def guardar(carpeta, slug, asunto, pre, cuerpo, donde, variables, texto):
    open(f'{carpeta}/{slug}.html','w',encoding='utf-8').write(envoltura(pre, cuerpo))
    open(f'{carpeta}/{slug}.txt','w',encoding='utf-8').write(texto)
    IDX.append({'archivo':f'{carpeta}/{slug}.html','asunto':asunto,'preheader':pre,
                'donde':donde,'variables':variables})
    print(f'  {slug:34} {len(envoltura(pre,cuerpo).encode()):>6} bytes')

# ══════════════════ AUTENTICACIÓN ══════════════════
print('autenticacion/')

# 1 · CONFIRMAR ALTA  🔴 el urgente
guardar('autenticacion','01-confirmar-alta',
 'Confirma tu correo para entrar a ATP',
 'Un clic y tu cuenta queda lista.',
 H('Confirma tu correo')
 + p('Creaste una cuenta en ATP con esta dirección. Falta un paso para que quede lista, y es confirmar que el correo es tuyo.')
 + boton('Confirmar mi correo', CONF + 'email')
 + p('El enlace sirve una sola vez. Si ya venció, vuelve a la app y pide otro desde la pantalla de entrada.', color=SEC, size=15, mt=8)
 + ESP(10) + HR
 + p('Si no creaste ninguna cuenta, ignora este correo y aquí se acaba. No se activa nada sin que le des al botón.', color=SEC, size=15, mb=0),
 'Authentication · Email Templates · Confirm signup',
 '{{ .SiteURL }} · {{ .TokenHash }} · {{ .Email }}',
"""Confirma tu correo

Creaste una cuenta en ATP con esta dirección. Falta un paso para que quede lista, y es confirmar que el correo es tuyo.

Confirma aquí:
{{ .SiteURL }}/confirmar.html?token_hash={{ .TokenHash }}&type=email

El enlace sirve una sola vez. Si ya venció, vuelve a la app y pide otro desde la pantalla de entrada.

Si no creaste ninguna cuenta, ignora este correo y aquí se acaba.

ATP · Querétaro, México · somosatp.com""")

# 2 · RESTABLECER CONTRASEÑA (ya en producción, se incluye para tener el juego completo)
guardar('autenticacion','02-restablecer-contrasena',
 'Restablece tu contraseña de ATP',
 'Un enlace de un solo uso para poner tu contraseña.',
 H('Restablece tu contraseña')
 + p('Alguien pidió cambiar la contraseña de la cuenta {{ .Email }}. Si fuiste tú, el botón de abajo te lleva a ponerla.')
 + boton('Poner nueva contraseña', RESET + 'recovery')
 + p('El enlace sirve una sola vez y dura poco, a propósito. Si ya venció, pides otro desde la pantalla de entrada de la app.', color=SEC, size=15, mt=8)
 + ESP(10) + HR
 + p('Si no fuiste tú, ignora este correo. Tu contraseña sigue igual y nadie entró a tu cuenta. Si te llegan varios de estos seguidos, avísanos.', color=SEC, size=15, mb=0),
 'Authentication · Email Templates · Reset password  ✅ YA APLICADA',
 '{{ .SiteURL }} · {{ .TokenHash }} · {{ .Email }}',
"""Restablece tu contraseña

Alguien pidió cambiar la contraseña de la cuenta {{ .Email }}. Si fuiste tú, abre este enlace:

{{ .SiteURL }}/reset-password.html?token_hash={{ .TokenHash }}&type=recovery

El enlace sirve una sola vez y dura poco, a propósito.

Si no fuiste tú, ignora este correo. Tu contraseña sigue igual y nadie entró a tu cuenta.

ATP · Querétaro, México · somosatp.com""")

# 3 · CAMBIO DE CORREO
guardar('autenticacion','03-cambio-de-correo',
 'Confirma tu correo nuevo en ATP',
 'Falta confirmar la dirección nueva.',
 H('Confirma tu correo nuevo')
 + p('Pediste cambiar el correo de tu cuenta de ATP. Para que el cambio quede, hay que confirmar la dirección nueva.')
 + dato('Correo nuevo','{{ .NewEmail }}')
 + boton('Confirmar el cambio', CONF + 'email_change')
 + p('Hasta que confirmes, tu cuenta sigue entrando con la dirección de siempre. Nada se pierde mientras tanto.', color=SEC, size=15, mt=8)
 + ESP(10) + HR
 + p(AVISO, color=SEC, size=15, mb=0),
 'Authentication · Email Templates · Change email address',
 '{{ .SiteURL }} · {{ .TokenHash }} · {{ .Email }} · {{ .NewEmail }}',
"""Confirma tu correo nuevo

Pediste cambiar el correo de tu cuenta de ATP. Para que el cambio quede, hay que confirmar la dirección nueva: {{ .NewEmail }}

Confirma aquí:
{{ .SiteURL }}/confirmar.html?token_hash={{ .TokenHash }}&type=email_change

Hasta que confirmes, tu cuenta sigue entrando con la dirección de siempre.

ATP · Querétaro, México · somosatp.com""")

# 4 · ENLACE DE ENTRADA (magic link)
guardar('autenticacion','04-enlace-de-entrada',
 'Tu enlace para entrar a ATP',
 'Un enlace de un solo uso, sin contraseña.',
 H('Aquí está tu enlace')
 + p('Con este botón entras a tu cuenta sin escribir contraseña. Sirve una sola vez y dura pocos minutos.')
 + boton('Entrar a ATP', CONF + 'email')
 + p('Si el enlace ya venció, pide otro desde la pantalla de entrada. Se generan al momento.', color=SEC, size=15, mt=8)
 + ESP(10) + HR
 + p(AVISO, color=SEC, size=15, mb=0),
 'Authentication · Email Templates · Magic link  (hoy sin uso)',
 '{{ .SiteURL }} · {{ .TokenHash }} · {{ .Email }}',
"""Aquí está tu enlace

Con este enlace entras a tu cuenta sin escribir contraseña. Sirve una sola vez y dura pocos minutos.

{{ .SiteURL }}/confirmar.html?token_hash={{ .TokenHash }}&type=email

ATP · Querétaro, México · somosatp.com""")

# 5 · INVITACIÓN
guardar('autenticacion','05-invitacion',
 'Te invitamos a ATP',
 'Pon tu contraseña y tu cuenta queda lista.',
 H('Te abrimos una cuenta')
 + p('Te creamos una cuenta de ATP con esta dirección. Solo falta que pongas tu contraseña y ya estás dentro.')
 + boton('Poner mi contraseña', RESET + 'invite')
 + p('Ocho caracteres mínimo, y que no la uses en otro lado. Después entras a la app con este mismo correo.', color=SEC, size=15, mt=8)
 + ESP(10) + HR
 + p('Si crees que esta invitación no era para ti, respóndenos y lo revisamos.', color=SEC, size=15, mb=0),
 'Authentication · Email Templates · Invite user  (hoy sin uso)',
 '{{ .SiteURL }} · {{ .TokenHash }} · {{ .Email }}',
"""Te abrimos una cuenta

Te creamos una cuenta de ATP con esta dirección. Solo falta que pongas tu contraseña.

{{ .SiteURL }}/reset-password.html?token_hash={{ .TokenHash }}&type=invite

Ocho caracteres mínimo, y que no la uses en otro lado.

ATP · Querétaro, México · somosatp.com""")

# 6 · REAUTENTICACIÓN (código, sin enlace)
guardar('autenticacion','06-reautenticacion',
 'Tu código de confirmación de ATP',
 'Un código de seis dígitos, válido unos minutos.',
 H('Tu código de confirmación')
 + p('Estás por hacer un cambio importante en tu cuenta y la app te va a pedir este código.')
 + dato('Código','{{ .Token }}', mono=True)
 + p('Dura pocos minutos y sirve una sola vez. No se lo compartas a nadie, y ten en cuenta que nosotros nunca te lo vamos a pedir.', color=SEC, size=15)
 + ESP(6) + HR
 + p('Si no estabas haciendo ningún cambio, ignora este correo y avísanos respondiendo aquí.', color=SEC, size=15, mb=0),
 'Authentication · Email Templates · Reauthentication  (hoy sin uso)',
 '{{ .Token }} · {{ .Email }}',
"""Tu código de confirmación

Estás por hacer un cambio importante en tu cuenta y la app te va a pedir este código.

Código: {{ .Token }}

Dura pocos minutos y sirve una sola vez. No se lo compartas a nadie. Nosotros nunca te lo vamos a pedir.

ATP · Querétaro, México · somosatp.com""")

# ══════════════════ SEGURIDAD ══════════════════
print('seguridad/')

def aviso(slug, asunto, pre, titulo, entrada, campos, donde, variables, texto):
    cuerpo = H(titulo) + p(entrada)
    for et, val in campos:
        cuerpo += dato(et, val)
    cuerpo += (ESP(6) + HR
      + p('Si fuiste tú, aquí no hay nada que hacer. Si no fuiste tú, responde a este correo ahora mismo y lo revisamos contigo.', color=SEC, size=15, mb=0))
    guardar('seguridad', slug, asunto, pre, cuerpo, donde, variables, texto)

aviso('01-contrasena-cambiada','Tu contraseña de ATP cambió','Si no fuiste tú, avísanos ahora.',
 'Tu contraseña cambió',
 'La contraseña de la cuenta {{ .Email }} se acaba de cambiar. Te avisamos siempre que esto pasa, aunque hayas sido tú.',
 [], 'Authentication · Security · Password changed', '{{ .Email }}',
"""Tu contraseña cambió

La contraseña de la cuenta {{ .Email }} se acaba de cambiar.

Si fuiste tú, aquí no hay nada que hacer. Si no fuiste tú, responde a este correo ahora mismo.

ATP · Querétaro, México · somosatp.com""")

aviso('02-correo-cambiado','El correo de tu cuenta de ATP cambió','Si no fuiste tú, avísanos ahora.',
 'El correo de tu cuenta cambió',
 'La dirección con la que entras a ATP se acaba de cambiar. Te mandamos este aviso a las dos, la vieja y la nueva.',
 [('Antes','{{ .OldEmail }}'), ('Ahora','{{ .Email }}')],
 'Authentication · Security · Email address changed', '{{ .OldEmail }} · {{ .Email }}',
"""El correo de tu cuenta cambió

Antes: {{ .OldEmail }}
Ahora: {{ .Email }}

Si fuiste tú, aquí no hay nada que hacer. Si no fuiste tú, responde a este correo ahora mismo.

ATP · Querétaro, México · somosatp.com""")

aviso('03-telefono-cambiado','El teléfono de tu cuenta de ATP cambió','Si no fuiste tú, avísanos ahora.',
 'El teléfono de tu cuenta cambió',
 'El número asociado a tu cuenta de ATP se acaba de cambiar.',
 [('Antes','{{ .OldPhone }}'), ('Ahora','{{ .Phone }}')],
 'Authentication · Security · Phone number changed', '{{ .OldPhone }} · {{ .Phone }}',
"""El teléfono de tu cuenta cambió

Antes: {{ .OldPhone }}
Ahora: {{ .Phone }}

Si no fuiste tú, responde a este correo ahora mismo.

ATP · Querétaro, México · somosatp.com""")

aviso('04-metodo-vinculado','Se agregó una forma de entrar a tu cuenta de ATP','Si no fuiste tú, avísanos ahora.',
 'Se agregó una forma de entrar',
 'Ahora tu cuenta de ATP también se puede abrir con otro método, además del que ya usabas.',
 [('Método agregado','{{ .Provider }}'), ('Cuenta','{{ .Email }}')],
 'Authentication · Security · Sign-in method linked', '{{ .Provider }} · {{ .Email }}',
"""Se agregó una forma de entrar

Método agregado: {{ .Provider }}
Cuenta: {{ .Email }}

Si no fuiste tú, responde a este correo ahora mismo.

ATP · Querétaro, México · somosatp.com""")

aviso('05-metodo-quitado','Se quitó una forma de entrar a tu cuenta de ATP','Si no fuiste tú, avísanos ahora.',
 'Se quitó una forma de entrar',
 'Se eliminó uno de los métodos con los que se podía abrir tu cuenta de ATP.',
 [('Método quitado','{{ .Provider }}'), ('Cuenta','{{ .Email }}')],
 'Authentication · Security · Sign-in method removed', '{{ .Provider }} · {{ .Email }}',
"""Se quitó una forma de entrar

Método quitado: {{ .Provider }}
Cuenta: {{ .Email }}

Si no fuiste tú, responde a este correo ahora mismo.

ATP · Querétaro, México · somosatp.com""")

aviso('06-mfa-agregado','Activaste verificación en dos pasos en ATP','Tu cuenta quedó con una capa más.',
 'Activaste verificación en dos pasos',
 'Tu cuenta de ATP ahora pide un segundo paso para entrar. Es la forma más simple de que nadie entre solo con tu contraseña.',
 [('Método','{{ .FactorType }}')],
 'Authentication · Security · MFA factor enrolled', '{{ .FactorType }} · {{ .Email }}',
"""Activaste verificación en dos pasos

Método: {{ .FactorType }}

Tu cuenta ahora pide un segundo paso para entrar.

Si no fuiste tú, responde a este correo ahora mismo.

ATP · Querétaro, México · somosatp.com""")

aviso('07-mfa-quitado','Se desactivó la verificación en dos pasos de ATP','Si no fuiste tú, avísanos ahora.',
 'Se desactivó la verificación en dos pasos',
 'Tu cuenta de ATP ya no pide un segundo paso para entrar. Ahora basta con la contraseña.',
 [('Método quitado','{{ .FactorType }}')],
 'Authentication · Security · MFA factor unenrolled', '{{ .FactorType }} · {{ .Email }}',
"""Se desactivó la verificación en dos pasos

Método quitado: {{ .FactorType }}

Tu cuenta ya no pide un segundo paso para entrar.

Si no fuiste tú, responde a este correo ahora mismo.

ATP · Querétaro, México · somosatp.com""")

open('INDICE.json','w',encoding='utf-8').write(json.dumps(IDX, ensure_ascii=False, indent=2))
print(f'\ntotal: {len(IDX)} plantillas')
