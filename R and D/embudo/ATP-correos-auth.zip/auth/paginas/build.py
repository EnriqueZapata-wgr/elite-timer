# -*- coding: utf-8 -*-
from base import pagina

JS = """
<script>
(function(){
  var $ = function(id){ return document.getElementById(id); };
  function ver(cual){
    ['cargando','listo','vencido'].forEach(function(id){ $(id).classList.toggle('oculto', id !== cual); });
  }
  function limpiarURL(){ try { history.replaceState(null,'',location.pathname); } catch(e){} }

  var q  = new URLSearchParams(location.search);
  var th = q.get('token_hash');
  var tipo = q.get('type') || 'email';

  // Textos por tipo, para que la pantalla diga lo que de verdad pasó
  var COPY = {
    'email':        { t:'Tu correo quedó confirmado',  d:'Tu cuenta ya está lista. Vuelve a la app y entra con tu correo y tu contraseña.' },
    'email_change': { t:'Tu correo nuevo quedó',       d:'A partir de ahora entras con la dirección nueva. La anterior deja de servir para entrar.' },
    'magiclink':    { t:'Listo, ya te reconocimos',    d:'Vuelve a la app en este mismo teléfono y ya deberías estar dentro.' }
  };

  if (!th) { ver('vencido'); return; }

  var API = ATP_SUPABASE_URL.replace(/\\/+$/,'') + '/auth/v1';
  var reloj = setTimeout(function(){ ver('vencido'); }, 15000);

  fetch(API + '/verify', {
    method:'POST',
    headers:{ 'Content-Type':'application/json', 'apikey': ATP_SUPABASE_ANON },
    body: JSON.stringify({ type: tipo, token_hash: th })
  })
  .then(function(r){ return r.json().then(function(j){ return { ok:r.ok, j:j }; }); })
  .then(function(r){
    clearTimeout(reloj); limpiarURL();
    if (!r.ok || !r.j.access_token) { ver('vencido'); return; }
    var c = COPY[tipo] || COPY['email'];
    $('titulo').textContent = c.t;
    $('detalle').textContent = c.d;
    ver('listo');
  })
  .catch(function(){ clearTimeout(reloj); limpiarURL(); ver('vencido'); });
})();
</script>"""

html = pagina("Confirmación · ATP", """
<div id="cargando"><p class="lead">Confirmando...</p></div>

<div id="listo" class="oculto">
  <h1 id="titulo">Tu correo quedó confirmado</h1>
  <p class="lead" id="detalle">Tu cuenta ya está lista. Vuelve a la app y entra con tu correo y tu contraseña.</p>
  <p>Ya puedes cerrar esta página.</p>
  <div class="hr"></div>
  <h2>Si es tu primer día</h2>
  <p>Entra con el teléfono cargado y veinte minutos libres. La app pregunta bastante al principio, y de esas respuestas sale todo lo que hace después. Contestar de prisa la primera vez se paga caro más adelante.</p>
</div>

<div id="vencido" class="oculto">
  <h1>Este enlace ya venció</h1>
  <p class="lead">Los enlaces de confirmación sirven una sola vez y duran poco, a propósito.</p>
  <p>Vuelve a la app y pide otro desde la pantalla de entrada. Te llega en menos de un minuto. Si ya lo intentaste y sigue sin funcionar, respóndele al correo que te mandamos y lo resolvemos contigo.</p>
</div>
""", extra_js='<script>var ATP_SUPABASE_URL="{{SUPABASE_URL}}";var ATP_SUPABASE_ANON="{{SUPABASE_ANON_KEY}}";</script>' + JS)

open('confirmar.html','w',encoding='utf-8').write(html)
print('confirmar.html', len(html), 'bytes')
