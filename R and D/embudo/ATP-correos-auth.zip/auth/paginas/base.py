# -*- coding: utf-8 -*-
CSS = """
*,*::before,*::after{box-sizing:border-box}
:root{
  --canvas:#000000; --card:#121212; --alto:#232323; --borde:#1F1F1F;
  --tinta:#FFFFFF; --sec:#999999; --tenue:#8E8E8E;
  --lima:#A8E02A; --teal:#1ABC9C;
  --g1:#A8E02A; --g2:#6DCC48; --g3:#3DBF6E; --g4:#2EC28A; --g5:#1ABC9C;
}
html,body{margin:0;padding:0}
body{
  background:var(--canvas); color:var(--tinta); min-height:100vh;
  font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  font-size:17px; line-height:1.65; -webkit-font-smoothing:antialiased;
}
/* riel de firma: el degradado recorre toda la altura de la pagina */
body::before{
  content:''; position:fixed; left:0; top:0; bottom:0; width:6px; z-index:10;
  background:linear-gradient(180deg,var(--g1),var(--g2) 26%,var(--g3) 50%,var(--g4) 74%,var(--g5));
}
.wrap{max-width:680px;margin:0 auto;padding:56px 24px 80px 30px}
.marca{display:block;width:132px;height:auto;margin:0 0 44px}
h1{font-size:clamp(30px,5.4vw,42px);line-height:1.14;font-weight:600;letter-spacing:-.022em;margin:0 0 20px}
h2{font-size:19px;line-height:1.35;font-weight:600;letter-spacing:-.008em;margin:0 0 14px}
p{margin:0 0 18px;color:var(--sec)}
p.lead{color:var(--tinta);font-size:19px;line-height:1.6}
strong{color:var(--tinta);font-weight:600}
a{color:var(--teal);text-decoration:none;font-weight:500}
a:hover{text-decoration:underline}
.tarjeta{background:var(--card);border:1px solid var(--borde);border-radius:16px;padding:28px 26px;margin:0 0 18px}
.campo{background:var(--alto);border:1px solid var(--borde);border-radius:12px;padding:18px 20px;margin:0 0 14px}
.etiqueta{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--tenue);margin:0 0 7px;font-weight:500}
.codigo{font-family:'SFMono-Regular',Consolas,'Liberation Mono',monospace;font-size:26px;font-weight:600;letter-spacing:.06em;color:var(--tinta);word-break:break-all}
.valor{font-size:18px;font-weight:600;color:var(--tinta)}
.btn{display:inline-flex;align-items:center;gap:10px;background:var(--lima);color:#000;font-weight:600;font-size:16px;
  padding:15px 28px;border-radius:12px;border:0;cursor:pointer;text-decoration:none;transition:transform .12s ease}
.btn:hover{transform:translateY(-1px);text-decoration:none}
.btn.fantasma{background:transparent;color:var(--tinta);border:1px solid #4A4A4A}
.fila{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 8px}
.hr{height:1px;background:var(--borde);margin:34px 0 30px}
.pie{color:var(--tenue);font-size:14px;line-height:1.6;margin-top:44px}
.pie a{color:var(--sec)}
.paso{display:flex;gap:16px;margin:0 0 20px;align-items:flex-start}
.num{flex:0 0 30px;height:30px;border-radius:50%;background:var(--alto);color:var(--sec);
  display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:600;margin-top:2px}
.paso div p{margin:0}
.aviso{border-left:3px solid var(--teal);padding:2px 0 2px 18px;margin:0 0 22px}
.aviso p{margin:0}
.oculto{display:none !important}
@media(max-width:520px){.wrap{padding:40px 20px 64px 26px} .codigo{font-size:21px}}
"""

def pagina(titulo, cuerpo, extra_js=""):
    return f"""<!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<meta name="referrer" content="no-referrer">
<title>{titulo}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>{CSS}</style>
</head>
<body>
<main class="wrap">
<img class="marca" src="/correo/logo-atp-blanco.png" alt="ATP">
{cuerpo}
</main>
{extra_js}
</body>
</html>"""
