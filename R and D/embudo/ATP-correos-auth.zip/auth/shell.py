# -*- coding: utf-8 -*-
import json, re

RAMPA = ['#A8E02A','#6DCC48','#3DBF6E','#2EC28A','#1ABC9C']
FONDO='#DBE2E7'; CARD='#E9EEF1'; BORDE='#CBD5DC'; CAMPO='#DDE5E9'
TINTA='#0F1518'; SEC='#4A555C'; TENUE='#5F6B73'   # tenue subido a 4.8:1 sobre el campo
TEAL='#086A5E'
FAM = "Poppins,'Segoe UI',Arial,sans-serif"
EXACT = "mso-line-height-rule:exactly;"

def barra():
    c=''.join('<td width="20%%" height="6" bgcolor="%s" style="background-color:%s;font-size:0;line-height:6px;%s">&nbsp;</td>'
              %(x,x,EXACT) for x in RAMPA)
    return ('<table role="presentation" width="100%%" cellpadding="0" cellspacing="0" border="0" '
            'style="border-collapse:collapse;"><tr>%s</tr></table>')%c

def boton(texto,href):
    ancho = max(190, len(texto)*11 + 62)
    return f"""<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:28px 0 8px;border-collapse:separate;">
<tr><td align="center" bgcolor="{TEAL}" style="background-color:{TEAL};border-radius:10px;padding:15px 30px;{EXACT}line-height:20px;">
<!--[if mso]><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="{href}" style="height:50px;v-text-anchor:middle;width:{ancho}px;" arcsize="20%" stroke="f" fillcolor="{TEAL}"><w:anchorlock/><center style="color:#FFFFFF;font-family:Arial,sans-serif;font-size:16px;font-weight:bold;">{texto}</center></v:roundrect><![endif]-->
<!--[if !mso]><!-- --><a href="{href}" style="font-family:{FAM};font-size:16px;font-weight:600;color:#FFFFFF;text-decoration:none;line-height:20px;">{texto}</a><!--<![endif]-->
</td></tr></table>"""

def p(txt,color=None,size=16,mt=0,mb=16,lh=None):
    color = color or TINTA
    lh = lh or int(size*1.65)
    return (f'<p style="margin:{mt}px 0 {mb}px;font-family:{FAM};font-size:{size}px;'
            f'line-height:{lh}px;{EXACT}font-weight:400;color:{color};">{txt}</p>')

def dato(etiqueta,valor,mono=False):
    fam = "'SFMono-Regular',Consolas,'Courier New',monospace" if mono else FAM
    tam = 22 if mono else 17
    return (f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'style="margin:0 0 14px;border-collapse:separate;"><tr>'
            f'<td bgcolor="{CAMPO}" style="background-color:{CAMPO};border:1px solid {BORDE};'
            f'border-radius:10px;padding:16px 18px;">'
            f'<div style="font-family:{FAM};font-size:11px;line-height:14px;{EXACT}letter-spacing:.09em;'
            f'text-transform:uppercase;color:{TENUE};padding-bottom:6px;">{etiqueta}</div>'
            f'<div style="font-family:{fam};font-size:{tam}px;line-height:{tam+6}px;{EXACT}'
            f'font-weight:bold;color:{TINTA};letter-spacing:.04em;">{valor}</div>'
            f'</td></tr></table>')

RELLENO = '&#847;&zwnj;&nbsp;' * 60

def envoltura(preheader, cuerpo):
    return f"""<!doctype html>
<html lang="es-MX" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="x-apple-disable-message-reformatting">
<meta name="color-scheme" content="light only">
<meta name="supported-color-schemes" content="light only">
<title>ATP</title>
<!--[if mso]><noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>
<style>body,table,td,p,a,div{{font-family:Arial,sans-serif !important}}</style><![endif]-->
<style>
  :root{{color-scheme:light only;supported-color-schemes:light only}}
  a{{color:{TEAL}}}
  @media (max-width:620px){{
    .caja{{padding:28px 22px !important}}
    .h1{{font-size:25px !important;line-height:31px !important}}
  }}
</style>
</head>
<body style="margin:0;padding:0;background-color:{FONDO};" bgcolor="{FONDO}">
<div style="display:none;font-size:1px;color:{FONDO};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">{preheader}{RELLENO}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="{FONDO}" style="background-color:{FONDO};border-collapse:collapse;">
<tr><td align="center" style="padding:32px 16px 48px;">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;border-collapse:collapse;">

<tr><td align="center" style="padding:0 0 26px;">
<img src="https://somosatp.com/correo/logo-atp.png" width="148" alt="ATP" style="display:block;border:0;outline:none;text-decoration:none;width:148px;height:auto;">
</td></tr>

<tr><td bgcolor="{CARD}" style="background-color:{CARD};border:1px solid {BORDE};border-radius:16px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
<tr><td style="border-radius:16px 16px 0 0;overflow:hidden;">{barra()}</td></tr>
<tr><td class="caja" style="padding:38px 38px 34px;">
{cuerpo}
</td></tr></table>
</td></tr>

<tr><td style="padding:26px 8px 0;">
<p style="margin:0 0 8px;font-family:{FAM};font-size:13px;line-height:20px;{EXACT}color:{SEC};">
Te escribimos porque compraste una membresía ATP. Si no fuiste tú, respóndenos y lo revisamos.
</p>
<p style="margin:0;font-family:{FAM};font-size:13px;line-height:20px;{EXACT}color:{SEC};">
ATP · Querétaro, México · <a href="https://somosatp.com" style="color:{TEAL};text-decoration:none;">somosatp.com</a>
</p>
</td></tr>

</table></td></tr></table></body></html>"""

H  = lambda t: (f'<h1 class="h1" style="margin:0 0 20px;font-family:{FAM};font-size:29px;'
                f'line-height:35px;{EXACT}font-weight:bold;color:{TINTA};letter-spacing:-.012em;">{t}</h1>')
H2 = lambda t: (f'<h2 style="margin:0 0 14px;font-family:{FAM};font-size:17px;line-height:23px;{EXACT}'
                f'font-weight:bold;color:{TINTA};">{t}</h2>')
HR = (f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">'
      f'<tr><td height="1" bgcolor="{BORDE}" style="background-color:{BORDE};font-size:0;line-height:1px;{EXACT}">&nbsp;</td></tr>'
      f'</table><div style="height:26px;line-height:26px;font-size:0;{EXACT}">&nbsp;</div>')
ESP = lambda h=26: f'<div style="height:{h}px;line-height:{h}px;font-size:0;{EXACT}">&nbsp;</div>'
B  = lambda t: f'<strong style="color:{TINTA};font-weight:bold;">{t}</strong>'
WA = 'https://wa.me/{{whatsapp_e164}}'

